class ReimplementEnumerable
  def initialize(collection)
    @collection = collection
  end

  def all?
  end

  def count
  end

  def find
  end

  def each_with_index
  end

  def drop(n)
  end

  def drop_while
  end

  def find_index
  end

  def include?(search)
  end

  def map
  end

  def max_by
  end

  def min_by
  end

  def none?
  end

  def one?
  end

  def partition
  end

  def reject
  end

  def select
  end

  def reverse_each
  end
end
